from pathlib import Path
import sys,os,signal,json
code,marker,sig=sys.argv[1:4];sys.path.insert(0,str(Path(code)/"src"))
import exact_pricer_expanded as e
import master_lp_gurobi as g
import event_pricer_network as n
sent=[False];original=n.EventExpandedNetwork.sink_predecessor_route_batch;solve=g.GurobiRestrictedMaster.solve

def wrapped(self,*a,**kw):
 if not sent[0]:
  sent[0]=True
  with open(marker,"a") as f:f.write("signal_sent\n")
  os.kill(os.getpid(),getattr(signal,sig))
 return original(self,*a,**kw)
def master(self,*a,**kw):
 if sent[0]:
  with open(marker,"a") as f:f.write("master_solve_after_signal\n")
 return solve(self,*a,**kw)
n.EventExpandedNetwork.sink_predecessor_route_batch=wrapped
g.GurobiRestrictedMaster.solve=master
raise SystemExit(e.main(sys.argv[4:]))
